package personal.programming.algos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgosApplication.class, args);
	}

}
